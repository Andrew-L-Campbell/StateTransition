package Campbell;

public interface State {

    void pull(FanPullChain fanPullChain);
}
